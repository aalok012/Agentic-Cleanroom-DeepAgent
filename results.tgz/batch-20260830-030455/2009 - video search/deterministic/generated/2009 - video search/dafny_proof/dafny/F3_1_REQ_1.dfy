include "Replay.dfy"

module F3_1_REQ_1Domain refines Domain {
  datatype Model = Unit

  datatype Action = None

  ghost predicate Inv(m: Model) {
    true
  }

  function Init(): Model {
    Unit
  }

  function Apply(m: Model, a: Action): Model {
    match a
    case None => m
  }

  function Normalize(m: Model): Model {
    m
  }

  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
  }

  lemma PostconditionForNoneAction(m: Model)
    ensures true
  {
  }
}

module F3_1_REQ_1Kernel refines Kernel {
  import D = F3_1_REQ_1Domain
}