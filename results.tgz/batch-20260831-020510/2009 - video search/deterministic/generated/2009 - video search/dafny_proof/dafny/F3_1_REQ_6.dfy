include "Replay.dfy"

module F3_1_REQ_6Domain refines Domain {
  // The model is the state of the search results
  datatype SearchResult = SearchResult(size: int, date: int, name: string)
  type Model = seq<SearchResult>

  // Actions are the ways the state can change
  datatype Action = SortBySize | SortByDate | SortByName

  // Invariant: what must always be true about the state
  ghost predicate Inv(m: Model) {
    forall i | 0 <= i < |m| :: m[i] != null
  }

  // Initial state
  function Init(): Model {
    []
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case SortBySize => sort(m, (x, y) => x.size <= y.size)
    case SortByDate => sort(m, (x, y) => x.date <= y.date)
    case SortByName => sort(m, (x, y) => x.name <= y.name)
  }

  // Normalization: fix invalid states (called after Apply)
  function Normalize(m: Model): Model {
    m
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
  }

  // Postcondition lemma for sorting by size
  lemma SortBySizePostcondition(m: Model)
    ensures forall i | 0 <= i < |Apply(m, SortBySize)| - 1 :: Apply(m, SortBySize)[i].size <= Apply(m, SortBySize)[i + 1].size
  {
    // The sort function ensures that the sequence is sorted by size
  }

  // Postcondition lemma for sorting by date
  lemma SortByDatePostcondition(m: Model)
    ensures forall i | 0 <= i < |Apply(m, SortByDate)| - 1 :: Apply(m, SortByDate)[i].date <= Apply(m, SortByDate)[i + 1].date
  {
    // The sort function ensures that the sequence is sorted by date
  }

  // Postcondition lemma for sorting by name
  lemma SortByNamePostcondition(m: Model)
    ensures forall i | 0 <= i < |Apply(m, SortByName)| - 1 :: Apply(m, SortByName)[i].name <= Apply(m, SortByName)[i + 1].name
  {
    // The sort function ensures that the sequence is sorted by name
  }

  // Helper function to sort a sequence based on a comparison function
  function sort(m: Model, cmp: (SearchResult, SearchResult) -> bool): Model {
    var result := m;
    var n := |result|;
    while n > 1
    {
      var new_n := 0;
      var i := 0;
      while i < n - 1
      {
        if !cmp(result[i], result[i + 1])
        {
          var temp := result[i];
          result[i] := result[i + 1];
          result[i + 1] := temp;
          new_n := i + 1;
        }
        i := i + 1;
      }
      n := new_n;
    }
    return result;
  }

  // Corrected helper function to sort a sequence based on a comparison function
  function sort(m: Model, cmp: (SearchResult, SearchResult) -> bool): Model {
    var result := m;
    var n := |result|;
    while n > 1
    {
      var new_n := 0;
      var i := 0;
      while i < n - 1
      {
        if cmp(result[i + 1], result[i])
        {
          var temp := result[i];
          result[i] := result[i + 1];
          result[i + 1] := temp;
          new_n := i + 1;
        }
        i := i + 1;
      }
      n := new_n;
    }
    return result;
  }
}

module F3_1_REQ_6Kernel refines Kernel {
  import D = F3_1_REQ_6Domain
}