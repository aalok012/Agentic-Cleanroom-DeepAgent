include "Replay.dfy"

module F3_1_REQ_5Domain refines Domain {
  type Model = bool  // True if "No results were found for this search." is displayed

  datatype Action = PerformSearch

  ghost predicate Inv(m: Model) {
    true  // Boolean flags are inherently valid
  }

  function Init(): Model {
    false  // Initially, no message is displayed
  }

  function Apply(m: Model, a: Action): Model {
    match a
    case PerformSearch => true  // Set flag to true when search is performed with no results
  }

  function Normalize(m: Model): Model {
    m  // No normalization needed for a boolean flag
  }

  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
  }

  lemma PostconditionForNoResultsFound()
    ensures Apply(false, PerformSearch) == true
  {
  }
}

module F3_1_REQ_5Kernel refines Kernel {
  import D = F3_1_REQ_5Domain
}