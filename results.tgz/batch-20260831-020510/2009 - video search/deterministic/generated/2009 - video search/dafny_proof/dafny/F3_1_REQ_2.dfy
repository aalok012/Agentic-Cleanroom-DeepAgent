include "Replay.dfy"

module F3_1_REQ_2Domain refines Domain {
  // The model is the database of torrent sites
  type Model = map<string, string>

  // Actions are the ways the state can change
  datatype Action = UpdateDatabase(newData: map<string, string>)

  // Invariant: all site URLs in the database are non-empty strings
  ghost predicate Inv(m: Model) {
    forall k | k in m :: m[k] != ""
  }

  // Initial state: an empty database
  function Init(): Model {
    map[]
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case UpdateDatabase(newData) => 
      map k | k in m.domain || k in newData.domain :: if k in newData then newData[k] else m[k]
  }

  // Normalization: remove entries with empty URLs
  function Normalize(m: Model): Model {
    map k | k in m && m[k] != "" :: m[k]
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
    match a
    case UpdateDatabase(newData) =>
      var updated := map k | k in m.domain || k in newData.domain :: if k in newData then newData[k] else m[k];
      var normalized := Normalize(updated);
      assert forall k | k in normalized :: normalized[k] != "";
  }

  // Postcondition lemma: the database contains the newly received data
  lemma UpdateDatabaseContainsNewData(m: Model, newData: map<string, string>)
    ensures forall k | k in newData :: newData[k] != "" ==> k in Normalize(Apply(m, UpdateDatabase(newData))) && Normalize(Apply(m, UpdateDatabase(newData)))[k] == newData[k]
  {
    var updated := map k | k in m.domain || k in newData.domain :: if k in newData then newData[k] else m[k];
    var normalized := Normalize(updated);
    assert forall k | k in newData :: newData[k] != "" ==> k in normalized && normalized[k] == newData[k];
  }
}

module F3_1_REQ_2Kernel refines Kernel {
  import D = F3_1_REQ_2Domain
}