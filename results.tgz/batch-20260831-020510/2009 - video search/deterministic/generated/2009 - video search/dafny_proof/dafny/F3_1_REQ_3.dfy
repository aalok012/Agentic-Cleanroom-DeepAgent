include "Replay.dfy"

module F3_1_REQ_3Domain refines Domain {
  // The model is a boolean indicating whether torrent searching is included
  type Model = bool

  // Actions are the ways the state can change
  datatype Action = ToggleTorrentSearch

  // Invariant: trivially true since the model is just a boolean
  ghost predicate Inv(m: Model) {
    true
  }

  // Initial state: torrent searching is initially excluded
  function Init(): Model {
    false
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case ToggleTorrentSearch => !m
  }

  // Normalization: trivial since the model is already valid
  function Normalize(m: Model): Model {
    m
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
  }

  // Postcondition lemma: toggling the torrent search sets the model correctly
  lemma ToggleTorrentSearchSetsModel(m: Model)
    ensures Apply(m, ToggleTorrentSearch) == !m
  {
  }
}

module F3_1_REQ_3Kernel refines Kernel {
  import D = F3_1_REQ_3Domain
}