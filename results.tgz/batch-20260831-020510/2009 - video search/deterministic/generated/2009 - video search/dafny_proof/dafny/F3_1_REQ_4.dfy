include "Replay.dfy"

module F3_1_REQ_4Domain refines Domain {
  // The model is a map from torrent IDs to their details
  type Model = map<string, TorrentDetails>

  // Details of a torrent
  datatype TorrentDetails = TorrentDetails(seeds: int, peers: int, size: int, datePosted: string, link: string)

  // Invariant: all torrent details are non-negative and links are non-empty
  ghost predicate Inv(m: Model) {
    forall t | t in m :: m[t].seeds >= 0 && m[t].peers >= 0 && m[t].size >= 0 && m[t].link != ""
  }

  // Initial state: empty map
  function Init(): Model {
    map[]
  }

  // Actions are the ways the state can change
  datatype Action = QueryTorrent(torrentId: string)

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case QueryTorrent(torrentId) => m
  }

  // Normalization: fix invalid states (called after Apply)
  function Normalize(m: Model): Model {
    map t | t in m :: 
      var td := m[t];
      var fixedSeeds := if td.seeds < 0 then 0 else td.seeds;
      var fixedPeers := if td.peers < 0 then 0 else td.peers;
      var fixedSize := if td.size < 0 then 0 else td.size;
      var fixedLink := if td.link == "" then "invalid_link" else td.link;
      TorrentDetails(fixedSeeds, fixedPeers, fixedSize, td.datePosted, fixedLink)
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
  }

  // Postcondition lemma for querying a torrent
  lemma QueryTorrentReturnsAccurateInfo(m: Model, torrentId: string)
    requires torrentId in m
    ensures m[torrentId] == Normalize(Apply(m, QueryTorrent(torrentId)))[torrentId]
  {
    var result := Normalize(Apply(m, QueryTorrent(torrentId)));
    assert torrentId in m; // Ensure torrentId is in the original map
    assert torrentId in result; // Ensure torrentId is in the result map
    assert result[torrentId] == m[torrentId];
  }
}

module F3_1_REQ_4Kernel refines Kernel {
  import D = F3_1_REQ_4Domain
}