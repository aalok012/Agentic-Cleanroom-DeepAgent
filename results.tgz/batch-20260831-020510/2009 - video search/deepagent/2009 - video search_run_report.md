# Run report

_SRS: 2009 - video search.xml · language: python · model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ_

## Run metrics

- **verification_pass_ratio**: 0.0
- **test_case_pass_ratio**: 0.0
- **PassVer@1**: 0.0
- **avg_verification_iteration**: 0.0
- **avg_test_iteration**: 0.0
- **avg_input_token**: 5556.7
- **avg_output_token**: 254.7
- **total_time**: 2215.75

## Timing & tokens (per stage)

| stage | seconds | input tok | output tok | calls |
|---|---|---|---|---|
| spec_parse | 0.00 | 0 | 0 | 0 |
| spec_contracts | 169.97 | 7,641 | 683 | 7 |
| dependency | 0.00 | 0 | 0 | 0 |
| planning | 156.85 | 47,866 | 624 | 7 |
| scaffold | 0.00 | 0 | 0 | 0 |
| dafny | 447.98 | 45,941 | 1,802 | 7 |
| compile | 0.00 | 0 | 0 | 0 |
| code | 953.30 | 45,738 | 3,843 | 7 |
| test | 487.65 | 47,299 | 1,962 | 7 |
| certification | 0.00 | 0 | 0 | 0 |
| **total** | **2215.75** | **194,485** | **8,914** | **35** |

## Tokens & cost

- total tokens: 203,399  (input 194,485 / output 8,914)
- LLM calls: 35
- estimated cost: $0.0000

## Generated code

- language: Python
- files: 0 · lines of code: 0
- files per layer: {}
- tech stack: Python standard library only

## Generated tests

- features: 7 · test cases: 0

## Certification (pass@k)

- samples n=1
- pass@1: 0.000
- case pass rate: 0.000

## Dafny proof tier (formal verification)

- model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ
- features: 7 · proved: 0 · rate: 0.000
  - 3.1.REQ-1 (F3_1_REQ_1): unproved (→ test track) (0r)
  - 3.1.REQ-2 (F3_1_REQ_2): unproved (→ test track) (0r)
  - 3.1.REQ-3 (F3_1_REQ_3): unproved (→ test track) (0r)
  - 3.1.REQ-4 (F3_1_REQ_4): unproved (→ test track) (0r)
  - 3.1.REQ-5 (F3_1_REQ_5): unproved (→ test track) (0r)
  - 3.1.REQ-6 (F3_1_REQ_6): unproved (→ test track) (0r)
  - 3.1.REQ-7 (F3_1_REQ_7): unproved (→ test track) (0r)

## Native compile (dafny translate py)

- compiled: 0 · failed: 7
