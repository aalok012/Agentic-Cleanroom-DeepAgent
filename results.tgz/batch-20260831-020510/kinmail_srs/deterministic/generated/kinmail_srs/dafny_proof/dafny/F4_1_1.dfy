include "Replay.dfy"

module F4_1_1Domain refines Domain {
  // The model is the state of the system, including registered users
  type Model = map<string, User>

  // User details
  datatype User = User(
    firstName: string,
    middleName: string,
    lastName: string,
    gender: string,
    profilePicture: string,
    contactNumber: string,
    birthdate: string,
    username: string,
    email: string,
    password: string,
    verified: bool
  )

  // Actions are the ways the state can change
  datatype Action = RegisterUser(
    firstName: string,
    middleName: string,
    lastName: string,
    gender: string,
    profilePicture: string,
    contactNumber: string,
    birthdate: string,
    username: string,
    email: string,
    password: string
  )

  // Invariant: all registered users have unique usernames and emails
  ghost predicate Inv(m: Model) {
    forall u1, u2 | u1 in m && u2 in m && u1 != u2 :: m[u1].username != m[u2].username && m[u1].email != m[u2].email
  }

  // Initial state: no users registered
  function Init(): Model {
    map[]
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case RegisterUser(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password) =>
      var newUser := User(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password, false);
      var result := m[username := newUser];
      result
  }

  // Normalization: fix invalid states (called after Apply)
  function Normalize(m: Model): Model {
    m
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
    match a
    case RegisterUser(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password) =>
      assert Inv(m);
      var newUser := User(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password, false);
      var result := m[username := newUser];
      assert forall u | u in m && u != username :: m[u].username != newUser.username && m[u].email != newUser.email;
      assert forall u | u in m && u != email :: m[u].username != newUser.username && m[u].email != newUser.email;
      assert Inv(result);
  }

  // Postcondition lemma for successful registration
  lemma RegistrationSuccessful(m: Model, a: Action)
    requires Inv(m)
    ensures Inv(Apply(m, a))
    ensures exists u | u in Apply(m, a) :: Apply(m, a)[u].verified == false
  {
    match a
    case RegisterUser(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password) =>
      assert Inv(m);
      var newUser := User(firstName, middleName, lastName, gender, profilePicture, contactNumber, birthdate, username, email, password, false);
      var result := m[username := newUser];
      assert forall u | u in m && u != username :: m[u].username != newUser.username && m[u].email != newUser.email;
      assert forall u | u in m && u != email :: m[u].username != newUser.username && m[u].email != newUser.email;
      assert username in result && result[username].verified == false;
      assert Inv(result);
  }
}

module F4_1_1Kernel refines Kernel {
  import D = F4_1_1Domain
}