# Run report

_SRS: kinmail_srs.xml · language: python · model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ_

## Run metrics

- **verification_pass_ratio**: 0.0
- **test_case_pass_ratio**: 0.0
- **PassVer@1**: 0.0
- **avg_verification_iteration**: 0.0
- **avg_test_iteration**: 0.0
- **avg_input_token**: 5553.5
- **avg_output_token**: 138.6
- **total_time**: 2245.41

## Timing & tokens (per stage)

| stage | seconds | input tok | output tok | calls |
|---|---|---|---|---|
| spec_parse | 0.00 | 0 | 0 | 0 |
| spec_contracts | 425.12 | 14,289 | 1,712 | 13 |
| dependency | 0.00 | 0 | 0 | 0 |
| planning | 393.81 | 88,781 | 1,575 | 13 |
| scaffold | 0.00 | 0 | 0 | 0 |
| dafny | 389.03 | 85,241 | 1,558 | 13 |
| compile | 0.00 | 0 | 0 | 0 |
| code | 402.67 | 84,903 | 1,613 | 13 |
| test | 634.77 | 87,763 | 2,550 | 13 |
| certification | 0.00 | 0 | 0 | 0 |
| **total** | **2245.41** | **360,977** | **9,008** | **65** |

## Tokens & cost

- total tokens: 369,985  (input 360,977 / output 9,008)
- LLM calls: 65
- estimated cost: $0.0000

## Generated code

- language: Python
- files: 0 · lines of code: 0
- files per layer: {}
- tech stack: Python standard library only

## Generated tests

- features: 13 · test cases: 0

## Certification (pass@k)

- samples n=1
- pass@1: 0.000
- case pass rate: 0.000

## Dafny proof tier (formal verification)

- model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ
- features: 13 · proved: 0 · rate: 0.000
  - 4.1.1 (F4_1_1): unproved (→ test track) (0r)
  - 4.1.2 (F4_1_2): unproved (→ test track) (0r)
  - 4.1.3 (F4_1_3): unproved (→ test track) (0r)
  - 4.1.4 (F4_1_4): unproved (→ test track) (0r)
  - 4.1.5 (F4_1_5): unproved (→ test track) (0r)
  - 4.2.1 (F4_2_1): unproved (→ test track) (0r)
  - 4.2.2 (F4_2_2): unproved (→ test track) (0r)
  - 4.2.3 (F4_2_3): unproved (→ test track) (0r)
  - 4.2.4 (F4_2_4): unproved (→ test track) (0r)
  - 4.2.5 (F4_2_5): unproved (→ test track) (0r)
  - 4.2.6 (F4_2_6): unproved (→ test track) (0r)
  - 4.2.7 (F4_2_7): unproved (→ test track) (0r)
  - 4.2.8 (F4_2_8): unproved (→ test track) (0r)

## Native compile (dafny translate py)

- compiled: 0 · failed: 13
