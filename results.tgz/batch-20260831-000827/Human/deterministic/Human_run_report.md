# Run report

_SRS: Human.xml · language: python · model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ_

## Run metrics

- **verification_pass_ratio**: 0.0
- **test_case_pass_ratio**: 0.5556
- **PassVer@1**: 0.0
- **avg_verification_iteration**: 6.0
- **avg_test_iteration**: 3
- **avg_input_token**: 3089.1
- **avg_output_token**: 549.9
- **total_time**: 3306.94

## Timing & tokens (per stage)

| stage | seconds | input tok | output tok | calls |
|---|---|---|---|---|
| spec_parse | 0.00 | 0 | 0 | 0 |
| spec_contracts | 49.30 | 2,199 | 189 | 2 |
| dependency | 0.00 | 0 | 0 | 0 |
| planning | 98.94 | 6,000 | 393 | 2 |
| scaffold | 0.00 | 0 | 0 | 0 |
| dafny | 2119.22 | 52,637 | 8,511 | 12 |
| compile | 0.00 | 0 | 0 | 0 |
| code | 127.77 | 3,270 | 513 | 2 |
| test | 643.99 | 4,743 | 2,600 | 2 |
| certification | 7.69 | 0 | 0 | 0 |
| recovery | 260.03 | 5,289 | 992 | 4 |
| **total** | **3306.94** | **74,138** | **13,198** | **24** |

## Tokens & cost

- total tokens: 87,336  (input 74,138 / output 13,198)
- LLM calls: 24
- estimated cost: $0.0000

## Generated code

- language: Python
- files: 2 · lines of code: 50
- files per layer: {'controller': 1, 'view': 1}
- tech stack: app, fastapi, sqlalchemy

## Generated tests

- features: 2 · test cases: 9

## Certification (pass@k)

- samples n=1
- pass@1: 0.000
- case pass rate: 0.556

## Recovery loop (re-prove + test-informed regen)

- passes run: 2 / 2 max
- re-proved (now ship from Dafny): (none)
- repaired with test feedback (clean-room relaxed): (none)
- still UNCERTIFIED: ['3.1', '3.2']

Final per-feature certification label:
  - 3.1: UNCERTIFIED
  - 3.2: UNCERTIFIED

## Dafny proof tier (formal verification)

- model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ
- features: 2 · proved: 0 · rate: 0.000
  - 3.1 (F3_1): unproved (→ test track) (6r)
  - 3.2 (F3_2): unproved (→ test track) (6r)

## Native compile (dafny translate py)

- compiled: 0 · failed: 2
