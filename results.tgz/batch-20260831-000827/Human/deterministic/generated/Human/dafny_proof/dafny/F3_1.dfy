include "Replay.dfy"

module F3_1Domain refines Domain {
  // The model is the state of the event, including details and registration requirements
  datatype Model = Model(details: string, registrationRequirements: string)

  // Actions are the ways the state can change
  datatype Action = EditEvent(newDetails: string, newRegistrationRequirements: string)

  // Invariant: what must always be true about the state
  ghost predicate Inv(m: Model) {
    m.details != "" && m.registrationRequirements != ""
  }

  // Initial state
  function Init(): Model {
    Model("Initial Details", "Initial Requirements")
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case EditEvent(newDetails, newRegistrationRequirements) =>
      var result := Model(newDetails, newRegistrationRequirements);
      assert result.details != "" && result.registrationRequirements != "";
      result
  }

  // Normalization: fix invalid states (called after Apply)
  function Normalize(m: Model): Model {
    if m.details == "" then {
      var result := Model("Default Details", m.registrationRequirements);
      assert result.details != "" && result.registrationRequirements != "";
      result
    }
    else if m.registrationRequirements == "" then {
      var result := Model(m.details, "Default Requirements");
      assert result.details != "" && result.registrationRequirements != "";
      result
    }
    else {
      m
    }
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
    var applied := Apply(m, a);
    var normalized := Normalize(applied);
    assert Inv(normalized);
  }

  // Postcondition lemma for editing the event
  lemma EditEventUpdatesDetailsAndRequirements(m: Model, newDetails: string, newRegistrationRequirements: string)
    ensures Inv(Apply(m, EditEvent(newDetails, newRegistrationRequirements)))
  {
    assert newDetails != "" && newRegistrationRequirements != "";
  }
}

module F3_1Kernel refines Kernel {
  import D = F3_1Domain
}