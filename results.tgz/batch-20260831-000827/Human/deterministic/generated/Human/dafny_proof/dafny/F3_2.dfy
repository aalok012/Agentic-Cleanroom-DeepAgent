include "Replay.dfy"

module F3_2Domain refines Domain {
  // The model is the state of the application
  datatype Model = Model(loggedIn: bool, registered: bool)

  // Actions are the ways the state can change
  datatype Action = AttemptRegister

  // Invariant: what must always be true about the state
  ghost predicate Inv(m: Model) {
    !(m.registered && !m.loggedIn)
  }

  // Initial state
  function Init(): Model {
    Model(loggedIn := false, registered := false)
  }

  // How actions transform the state
  function Apply(m: Model, a: Action): Model {
    match a
    case AttemptRegister => Model(loggedIn := m.loggedIn, registered := m.registered)
  }

  // Normalization: fix invalid states (called after Apply)
  function Normalize(m: Model): Model {
    if m.registered && !m.loggedIn then Model(loggedIn := m.loggedIn, registered := false) else m
  }

  // Proof that Init satisfies the invariant
  lemma InitSatisfiesInv()
    ensures Inv(Init())
  {
  }

  // Proof that every step preserves the invariant
  lemma StepPreservesInv(m: Model, a: Action)
    ensures Inv(Normalize(Apply(m, a)))
  {
    var nextModel := Apply(m, a)
    var normalizedModel := Normalize(nextModel)
    assert Inv(normalizedModel);
  }

  // Postcondition lemma for the AttemptRegister action
  lemma AttemptRegisterPostcondition(m: Model)
    ensures !(Normalize(Apply(m, AttemptRegister)).registered) ==> !m.loggedIn
  {
    var nextModel := Apply(m, AttemptRegister)
    var normalizedModel := Normalize(nextModel)
    if m.registered && !m.loggedIn {
      // If the user was registered and not logged in, Normalize will unregister them
      assert normalizedModel.registered == false;
    }
    assert !(normalizedModel.registered) ==> !m.loggedIn;
  }
}

module F3_2Kernel refines Kernel {
  import D = F3_2Domain
}