"""Spec-derived pytest module for feature 3.1.

Generated black-box from the specification (5 case(s)); the Test Agent never sees the implementation, so import paths follow
sensible module conventions and may need adjustment to bind to the concrete
generated package.
"""

import json
from fastapi.testclient import TestClient
from app import create_app

client = TestClient(create_app())

def test_edit_event_details_canonical():
    setup_json = '[{"inputs": {"event_id": "123", "details": {"name": "Old Name", "date": "2023-09-01"}, "registration_requirements": {"age_limit": 16, "max_participants": 50}}, "route": "POST /controllers/add_event"}]'
    for s in json.loads(setup_json):
        client.post(s.get("route", "POST /controllers/edit_event_details"), json=s["inputs"])
    inputs_json = "{\"event_id\":\"123\",\"new_details\":{\"name\":\"Tech Conference\",\"date\":\"2023-10-01\"},\"new_registration_requirements\":{\"age_limit\":18,\"max_participants\":100}}"
    resp = client.post("POST /controllers/edit_event_details", json=json.loads(inputs_json))
    assert resp.status_code == 200
    assert resp.json() == json.loads('null')

def test_edit_event_details_empty_new_details():
    setup_json = '[{"inputs": {"event_id": "123", "details": {"name": "Old Name", "date": "2023-09-01"}, "registration_requirements": {"age_limit": 16, "max_participants": 50}}, "route": "POST /controllers/add_event"}]'
    for s in json.loads(setup_json):
        client.post(s.get("route", "POST /controllers/edit_event_details"), json=s["inputs"])
    inputs_json = "{\"event_id\":\"123\",\"new_details\":{},\"new_registration_requirements\":{\"age_limit\":18,\"max_participants\":100}}"
    resp = client.post("POST /controllers/edit_event_details", json=json.loads(inputs_json))
    assert resp.status_code == 200
    assert resp.json() == json.loads('null')

def test_edit_event_details_empty_new_registration_requirements():
    setup_json = '[{"inputs": {"event_id": "123", "details": {"name": "Old Name", "date": "2023-09-01"}, "registration_requirements": {"age_limit": 16, "max_participants": 50}}, "route": "POST /controllers/add_event"}]'
    for s in json.loads(setup_json):
        client.post(s.get("route", "POST /controllers/edit_event_details"), json=s["inputs"])
    inputs_json = "{\"event_id\":\"123\",\"new_details\":{\"name\":\"Tech Conference\",\"date\":\"2023-10-01\"},\"new_registration_requirements\":{}}"
    resp = client.post("POST /controllers/edit_event_details", json=json.loads(inputs_json))
    assert resp.status_code == 200
    assert resp.json() == json.loads('null')

def test_edit_event_details_missing_event_id():
    inputs_json = "{\"new_details\":{\"name\":\"Tech Conference\",\"date\":\"2023-10-01\"},\"new_registration_requirements\":{\"age_limit\":18,\"max_participants\":100}}"
    resp = client.post("POST /controllers/edit_event_details", json=json.loads(inputs_json))
    assert resp.status_code >= 400

def test_edit_event_details_invalid_event_id():
    inputs_json = "{\"event_id\":\"999\",\"new_details\":{\"name\":\"Tech Conference\",\"date\":\"2023-10-01\"},\"new_registration_requirements\":{\"age_limit\":18,\"max_participants\":100}}"
    resp = client.post("POST /controllers/edit_event_details", json=json.loads(inputs_json))
    assert resp.status_code >= 400
