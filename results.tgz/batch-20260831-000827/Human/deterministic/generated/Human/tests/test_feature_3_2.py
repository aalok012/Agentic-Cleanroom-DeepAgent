"""Spec-derived pytest module for feature 3.2.

Generated black-box from the specification (4 case(s)); the Test Agent never sees the implementation, so import paths follow
sensible module conventions and may need adjustment to bind to the concrete
generated package.
"""

import json
from fastapi.testclient import TestClient
from app import create_app

client = TestClient(create_app())

def test_prompt_login_if_not_logged_in_anchor():
    resp = client.post("/views/prompt_login_if_not_logged_in", json={})
    assert resp.status_code == 200
    assert resp.json() == "Please log in to register for the event."

def test_prompt_login_if_not_logged_in_boundary():
    resp = client.post("/views/prompt_login_if_not_logged_in", json={})
    assert resp.status_code == 200
    assert resp.json() == "Please log in to register for the event."

def test_prompt_login_if_not_logged_in_independent():
    resp = client.post("/views/prompt_login_if_not_logged_in", json={"unexpected_key": "value"})
    assert resp.status_code == 200
    assert resp.json() == "Please log in to register for the event."

def test_prompt_login_if_not_logged_in_precondition_violation():
    resp = client.post("/views/prompt_login_if_not_logged_in", json=None)
    assert resp.status_code >= 400
