# Run report

_SRS: Human.xml · language: python · model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ_

## Run metrics

- **verification_pass_ratio**: 0.0
- **test_case_pass_ratio**: 0.0
- **PassVer@1**: 0.0
- **avg_verification_iteration**: 0.0
- **avg_test_iteration**: 0.0
- **avg_input_token**: 5554.3
- **avg_output_token**: 170.3
- **total_time**: 437.59

## Timing & tokens (per stage)

| stage | seconds | input tok | output tok | calls |
|---|---|---|---|---|
| spec_parse | 0.00 | 0 | 0 | 0 |
| spec_contracts | 47.25 | 2,199 | 190 | 2 |
| dependency | 0.00 | 0 | 0 | 0 |
| planning | 69.71 | 13,664 | 264 | 2 |
| scaffold | 0.00 | 0 | 0 | 0 |
| dafny | 65.43 | 13,112 | 249 | 2 |
| compile | 0.00 | 0 | 0 | 0 |
| code | 82.53 | 13,068 | 318 | 2 |
| test | 172.68 | 13,500 | 682 | 2 |
| certification | 0.00 | 0 | 0 | 0 |
| **total** | **437.59** | **55,543** | **1,703** | **10** |

## Tokens & cost

- total tokens: 57,246  (input 55,543 / output 1,703)
- LLM calls: 10
- estimated cost: $0.0000

## Generated code

- language: Python
- files: 0 · lines of code: 0
- files per layer: {}
- tech stack: Python standard library only

## Generated tests

- features: 2 · test cases: 0

## Certification (pass@k)

- samples n=1
- pass@1: 0.000
- case pass rate: 0.000

## Dafny proof tier (formal verification)

- model: Qwen/Qwen2.5-Coder-32B-Instruct-AWQ
- features: 2 · proved: 0 · rate: 0.000
  - 3.1 (F3_1): unproved (→ test track) (0r)
  - 3.2 (F3_2): unproved (→ test track) (0r)

## Native compile (dafny translate py)

- compiled: 0 · failed: 2
